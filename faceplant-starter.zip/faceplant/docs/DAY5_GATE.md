# Day 5 gate — FACEPLANT

The question this gate answers: **is the core mechanic fun enough to spend nine
more days on?** Art, sound and content cannot fix a mechanic that isn't.

## Setup (fill in on Day 4)

- Build URL / branch:
- Level used:
- Testers (never seen the game — SPEC Q3): 1. ______ 2. ______ 3. ______

## Protocol (follow exactly)

1. Sit the tester at the laptop with the game on the title screen.
2. Say only: **"Your face is the level. Get the little candles to the door."**
3. Do not explain anything else. Do not help. Do not react. Watch their face
   and the screen.
4. Let them play for **2 minutes**, then say "You can stop whenever you
   like" and note whether they keep going.
5. Afterwards ask only: "What was the game about?" and "What was annoying?"

## Technical precondition

- [ ] AC-3 passes (solver tests)
- [ ] AC-4 passes (fixture simulations, zero tunnelling)
- [ ] Tracking Hz on the test laptop: ____ (needs ≥ 20)

## Observations (one column per tester)

| Question | Tester 1 | Tester 2 | Tester 3 |
|---|---|---|---|
| Understood what to do within 30 s, without help? (Y/N) | | | |
| Laughed or smiled in the first minute? (Y/N) | | | |
| Mouth opened by accident at least once? (the hook working) | | | |
| Did it make them laugh, and the laugh cost Wicks? | | | |
| Kept playing after "you can stop"? (Y/N) | | | |
| Saw a physics moment they called unfair or broken? (describe) | | | |
| "What was the game about?" (their words) | | | |
| "What was annoying?" (their words) | | | |

## Decision rule (agreed before testing)

- **Continue** if: at least 2 of 3 understood unaided, **and** at least 2 of 3
  laughed, **and** nobody hit a physics bug they called unfair.
- **Fix and retest** (at most one extra day, then one new tester) if
  understanding or physics failed but people laughed.
- **Pivot** if nobody laughed or wanted to keep playing. Options: change the
  core mechanic (discuss with Claude using Prompt 7), or switch to the SHY
  concept.

## Decision

- Claude's recommendation (from Prompt 7):
- **My decision:** Continue / Fix and retest / Pivot
- Reason:
- Signed: ____________ Date: ____________
