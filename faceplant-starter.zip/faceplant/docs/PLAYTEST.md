# Playtest and manual-check record — FACEPLANT

Manual acceptance criteria are recorded here (SPEC §18). Each entry needs a
date. Claude may prepare checklists but only a human can tick them.

## AC-8 — Every MVP level completed in Assist mode (no camera)

| Level | Completed in Assist (Y/N) | Candles | Date | Notes |
|---|---|---|---|---|
| 01-1 | | | | |
| 01-2 | | | | |
| 01-3 | | | | |
| 01-4 | | | | |
| 02-1 | | | | |
| 02-2 | | | | |
| 02-3 | | | | |
| 03-1 | | | | |
| 03-2 | | | | |
| 03-3 | | | | |
| 04-1 | | | | |
| 04-2 (finale) | | | | |
| Daily Tape (today's) | | | | |

## AC-11 — Sharing (desktop Chrome)

| Check | Result | Date |
|---|---|---|
| Copy result text matches SPEC §16 format | | |
| Result card downloads at 1080×1350 | | |
| Recording on: clip previews and plays back | | |
| Clip format produced (MP4 / WebM) | | |
| Clip ends with the result card | | |
| Clip contains game audio and no microphone audio | | |
| Clip looks right in portrait on a phone | | |

## AC-12 — Deployment

| Check | Result | Date |
|---|---|---|
| GitHub Pages URL plays with the camera | | |
| itch.io behaviour (embedded / new window / blocked) | | |

## Playtest round 2 (Day 14) — same protocol as the Day 5 gate

| Question | Tester 1 | Tester 2 | Tester 3 |
|---|---|---|---|
| Understood within 30 s unaided? | | | |
| Laughed in the first minute? | | | |
| Mouth opened by accident (and cost Wicks)? | | | |
| Kept playing after "you can stop"? | | | |
| Tried a second level unprompted? | | | |
| Would they share a clip? (ask last) | | | |
| Most annoying thing (their words) | | | |

## Wick lines that landed / fell flat

| Line | Landed (got a laugh) / Flat | Who | Date |
|---|---|---|---|
| | | | |
