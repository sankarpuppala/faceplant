# PLAN.md — FACEPLANT

Status: **REFERENCE DRAFT — not yet approved.**

Written alongside `SPEC.md` so Claude Code starts from a strong position. It
must first be reviewed against `SPEC.md` (PROMPT.md, Prompt 2) and approved
by the human. Then change the line above to `APPROVED — <date>`.

Implements `SPEC.md` v1.0. Governed by `CLAUDE.md`.

---

## How the two weeks work

- **One plan-day per session.** Each day ends with its *Done when* checks
  passing, the *You check* items done by you, a Progress log entry, and a
  merge of `day-<nn>-<name>`.
- Each session starts by re-reading `CLAUDE.md`, `SPEC.md`, this day's
  section and the Progress log, listing the files it will touch and the
  ⚠ verify items, and waiting for "go".
- Days assume roughly 6–8 focused hours. Part-time: the order stays the same,
  each plan-day just takes longer (SPEC Q6).
- **The order is deliberate: correctness → fun → beauty → content → sharing.**
  Nothing pretty is built until Day 5 proves the core is fun.

| Day | Focus | Gate / output |
|---|---|---|
| 0 | Setup + camera-on-hosting test | Repo runs; camera verified on GitHub Pages and itch.io |
| 1 | Face input, debug page, fixtures | ≥ 6 recorded fixtures |
| 2 | Calibration, mapping, terrain, Maw | Terrain drawn live on your face |
| 3 | Solver + Wick behaviour + fixture sims | AC-3, AC-4 |
| 4 | Ugly playable level + Assist | Something a stranger can play |
| **5** | **GATE: three-tester playtest** | **Go / fix / pivot — your decision** |
| 6 | Look I: video, candlelight, contours, sprites, OSD | It looks like the reference |
| 7 | Look II: post-FX, filters, reduced effects, audio | AC-6 |
| 8 | Levels I: loader, rules, Tapes 01–02, Wick lines | 7 levels |
| 9 | Levels II: hazards, Tapes 03–04, scares, finale | 12 levels, AC-9 |
| 10 | Menus and screens | Full flow from title to ending |
| 11 | Sharing + privacy check | AC-5, AC-11 |
| 12 | Daily Tape, credits, behind-you scare | AC-13 |
| 13 | Stretch or polish; performance; Assist run | AC-7, AC-8 |
| 14 | Playtest round 2, tuning, deploy, final verify | AC-12, every AC green |

---

## Day 0 — Setup and the camera-hosting test

**Tasks**
1. Record versions of Node, npm, Git, Chrome in the Progress log.
2. Vite + TypeScript project; `vitest`; `tsconfig` strict; `.gitignore`
   (`node_modules`, `dist`, `*.webm`, `*.mp4`, recordings, `.env*`).
3. Install `pixi.js`, `pixi-filters`, `@mediapipe/tasks-vision`
   (⚠ verify current versions and that the `pixi-filters` major matches the
   PixiJS major). Pin exact versions.
4. `scripts/copy-mediapipe.ts`: copy the wasm folder and download/copy the
   `face_landmarker.task` and selfie-segmenter models into
   `public/mediapipe/` (⚠ verify the official model download location and
   licence; record it in `docs/CREDITS.md`). Decide whether these files are
   committed or regenerated, and record the decision.
5. Self-host fonts (VT323, Special Elite, Inter — all OFL) in `public/fonts/`.
6. Empty `src/config.ts`, `src/render/tokens.ts`, `src/ui/tokens.css` with
   the SPEC §12.2 tokens.
7. **Hosting test (important):** a bare page that turns on the camera and
   shows it. Deploy to GitHub Pages and upload to itch.io as an HTML5 game.
   Record exactly what happens on itch.io (works embedded / needs the
   fullscreen-or-new-window option / blocked).

**Done when** `npm run dev`, `npm test` (zero tests) and `npm run build`
work; the hosting test results are recorded.

**You check:** the camera test works from both URLs on your laptop.

---

## Day 1 — Face input, debug page, fixtures

**Tasks**
1. `src/face/types.ts` — `FaceFrame`, `FaceData`, `FaceSource` (SPEC §6.1).
2. `oneEuro.ts` + tests.
3. `webcamSource.ts` — Face Landmarker, VIDEO mode, blendshapes on, GPU
   delegate with CPU fallback, `numFaces` from config. ⚠ verify the current
   `FaceLandmarker` options API and the exported contour connection sets.
4. Debug page (`?debug`): video, all landmarks, named contours in colour,
   blendshape bars, render fps, tracking Hz.
5. **Record fixture** button: saves only the landmark indices the game uses
   plus the 5 blendshapes, with timestamps, as JSON.
6. `fixtureSource.ts` replays a fixture at its recorded timing.
7. Record **your own** fixtures (30–45 s each): `neutral`, `tilt`, `lean`,
   `brows`, `mouth-laugh` (open, close, real laughing), `head-jerk`.

**Done when** fixtures exist in `fixtures/faces/`; the fixture source
replays them in the debug page; tracking Hz is recorded.

**You check:** the debug overlay sticks to your face in your normal lighting;
note the tracking Hz and fps.

---

## Day 2 — Calibration, mapping, terrain, Maw

**Tasks**
1. `calibration.ts` — neutral centre, FH, jaw/brow baselines and ranges
   (SPEC §7), with jitter rejection. Tests.
2. `mapping.ts` — normalised landmarks → mirrored screen → FH world, and
   back. Round-trip tests.
3. `contours.ts`, `build.ts`, `walkable.ts` — ordered polylines per SPEC
   §6.3; one-way walkability classification. Tests on every fixture frame
   (no NaN, ordered left to right).
4. `maw.ts` — personal thresholds, hysteresis, minimum state time, swallow
   polygon. Tests.
5. `reactions.ts` — laughing, gasp, smiling, brows up, leaning in (SPEC
   §6.8). Tests on the `mouth-laugh` fixture.
6. Debug page draws the live terrain (walkable segments bright, ignored
   segments dim) and a Maw open/closed indicator.

**Done when** the Day-2 parts of AC-2 pass.

**You check:** open your mouth slowly and quickly — the Maw indicator should
never flicker. Laugh — the debug page should flag it.

---

## Day 3 — Solver, Wick behaviour, fixture simulations

**Tasks**
1. `solver.ts` — fixed-step integration, one-way moving polylines, swept
   test in the segment's frame, landing, surface-velocity inheritance (SPEC
   §8.4). **Write the AC-3 tests first.**
2. `wick.ts` — state machine, timid edges, gaps, slopes, flick, quake, Maw
   fear (SPEC §6.4–6.6, §8.1).
3. `tests/levels/fixture-arena.json` — a wide arena: ruins left and right,
   spawn above the face, Gate on the right.
4. Headless fixture simulations (AC-4): tunnelling detector + conservation
   check at every step, for every fixture.

**Done when** AC-3 and AC-4 pass. If AC-4 cannot pass with the custom solver
by the end of the day, stop and report — the fallback (Rapier2D) is a spec
change for the human to approve.

**You check:** ask Claude to show you the tunnelling detector failing on a
deliberately broken solver (a throwaway change), so you know the test has
teeth.

---

## Day 4 — Ugly playable level + Assist

**Tasks**
1. Minimal render: video, terrain lines, circles for Wicks, rectangles for
   ruins and the Gate. No styling.
2. One real level: spawn lantern, ruins, Gate, Maw swallowing, flick, quake,
   win/lose counting.
3. `syntheticSource.ts` — Assist face (SPEC §13): mouse position, scroll tilt,
   Space Maw, Shift brows, arrows lean. Same `FaceFrame` output.
4. A handful of placeholder Wick lines driven by reactions, including the
   first-ten-seconds sequence (SPEC §3.2).
5. Fill in the top of `docs/DAY5_GATE.md` (build link, what testers will be
   told).

**Done when** a person who has never seen the game can play the level from
the dev URL, with camera or Assist.

**You check:** play it yourself for 10 minutes. Write down three moments that
felt good and three that felt bad, for tomorrow.

---

## Day 5 — THE GATE

No new features. Today decides whether the next nine days are worth it.

**Tasks**
1. Fix only what blocks the playtest (crashes, a broken level).
2. Run the playtest exactly as written in `docs/DAY5_GATE.md` with three
   people who have never seen the game (SPEC Q3). Tell them only: *"Your face
   is the level. Get the little candles to the door."* Then stay silent and
   watch.
3. Record the answers in `docs/DAY5_GATE.md`.
4. Claude summarises the results and proposes a fix list, but **the decision
   is yours**: continue, spend at most one day on the fix list and re-test
   with one new person, or pivot.

**Done when** AC-10: the gate document is complete and you have signed the
decision.

---

## Day 6 — Look I

**Tasks.** Render stack layers 1–4 and 6 (SPEC §12.4): VHS-graded mirrored
video; darkness with candlelight holes (Wicks, lantern, Gate) and gentle
flicker; chalk contour line; sprites for Wicks (cream wax body, amber flame
with ember core, two dot eyes, a little walk bob), ruins (burnt-paper
silhouettes with amber rim), lantern, Gate (glowing doorway), Crawlers,
Drips; camcorder OSD (REC, timestamp, tape label, candle counter, Maw
indicator). Match `docs/design-reference.html` in feel.

**Done when** the Day-4 level looks like the reference and still runs at
≥ 30 fps.

**You check:** screenshots in a bright room and a dim room. Run Prompt 6
(design critique).

---

## Day 7 — Look II and audio

**Tasks.** Post-process via `pixi-filters` (scanlines, aberration, grain,
vignette, wobble); INK and THERMAL filters; reduced effects;
`scripts/check-flash.ts` and the reduced-effects test (AC-6). Audio manager
with limiter and attack rules (CLAUDE.md invariant 6); hiss/drone bed;
jsfxr squeaks, gulp, flame-out, chime, skitter, flick; `docs/CREDITS.md`.

**Done when** AC-6 passes and every sound is credited.

**You check:** play with headphones at a normal volume — nothing should be
painfully loud. Try INK mode: is the game still readable?

---

## Day 8 — Levels I

**Tasks.** `levelSchema.ts` + validator, `levelLoader.ts`, `rules.ts`
(candles, stamps, stats); Tape 01 (4 levels) and Tape 02 (3 levels, Crawlers)
per SPEC §9.3; `lines.ts` with ≥ 60 tagged lines and `lineDirector.ts`
(SPEC §12.7).

**Done when** all 7 levels validate (AC-2) and are completable with the
camera and in Assist.

**You check:** play all 7. Which Wick line made you laugh out loud? Which
ones fell flat? Feed that into Prompt 5.

---

## Day 9 — Levels II, hazards, scares, finale

**Tasks.** Drips and the Dark; Tape 03 (3 levels written to be funny) and
Tape 04 (2 levels, including the finale per SPEC §10.3); scare events
(`flicker`, `whisper`, `figure`, `stinger`) with the scares-off test (AC-9).

**Done when** all 12 levels validate and AC-9 passes.

**You check:** play Tape 04 with the lights off, then again with scares off.

---

## Day 10 — Menus and screens

**Tasks.** DOM screens from SPEC §12.5: first-launch notice, title, camera
explainer, calibration screen, tape shelf, pause, results (stamps, candle
animation, stats), settings, ending; `storage/` for progress and settings;
keyboard navigation and visible focus. Lost-tracking pause with the Assist
offer.

**Done when** the full journey title → calibration → shelf → level →
results → next → ending works with camera and in Assist, settings persist
across reloads.

**You check:** give the build to someone and say nothing. Can they get from
the title screen into a level alone?

---

## Day 11 — Sharing and privacy

**Tasks.** `shareText.ts` (SPEC §16 format, tests); `resultCard.ts`
(1080×1350 PNG); `portraitCanvas.ts` + `recorder.ts` (opt-in, MP4 if
supported else WebM — ⚠ verify `MediaRecorder.isTypeSupported` strings on
your Chrome; result card tail; preview dialog; nothing kept after the
dialog); `scripts/check-privacy.ts` and the dev-mode cross-origin observer
(AC-5).

**Done when** AC-5 passes and AC-11 is recorded in `docs/PLAYTEST.md`.

**You check:** record a clip, upload it privately to the short-video app you
use, and check it looks right in portrait.

---

## Day 12 — Daily Tape, credits test, behind-you scare

**Tasks.** `prng.ts` (mulberry32), `daily.ts` with ≥ 4 templates in
`public/levels/daily-templates/`, first-attempt storage, Daily label on the
shelf, daily share text (determinism test — AC-2); credits test (AC-13); the
segmentation scare (SPEC §10.2) if the performance budget allows, else the
`figure` fallback.

**Done when** the Day-12 parts of AC-2 pass and AC-13 passes.

**You check:** set your PC clock to tomorrow (or use a dev override) and
confirm the Daily Tape changes; confirm it is identical on two browsers today.

---

## Day 13 — Stretch or polish, performance, Assist run

**Tasks.** Your choice from SPEC Q4: Two Faces (Tape 05) *or* polish from
the playtest notes. Then: measure performance (AC-7) and adjust low-power
defaults; complete every level in Assist and record it (AC-8).

**Done when** AC-7 and AC-8 are recorded.

---

## Day 14 — Playtest, tune, deploy, verify

**Tasks.** Playtest round 2 with three new people (same protocol as Day 5,
recorded in `docs/PLAYTEST.md`); tuning pass (every change logged); deploy to
GitHub Pages and itch.io (AC-12); run Prompt 8 (verify every AC).

**Done when** every acceptance criterion in SPEC §18 is green, and you have
recorded a 15–20 second trailer clip of yourself playing (PROMPT.md Part E).

---

## Risks

| # | Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|---|
| R1 | Moving-terrain physics jitters or tunnels | Medium | High | Swept test, smoothing, fixture sims on Day 3, Rapier fallback |
| R2 | The mechanic is novel but not fun | Medium | High | Day 5 gate before any art or content |
| R3 | Tracking poor in dim rooms (and the theme is dark) | Medium | Medium | Darkness is rendered, not required in the room; calibration rejects bad tracking; Assist fallback |
| R4 | itch.io iframe blocks the camera | Medium | Low | Tested on Day 0; new-window launch or GitHub Pages link |
| R5 | Low-end laptops can't keep 30 fps | Medium | Medium | Low-power mode; segmentation only in scare windows |
| R6 | Scares harm or alienate players | Low | High | Opt-out, notice, flash and audio limits, tests |
| R7 | Players won't share their face | High | Medium | Flattering filters, INK hide-my-face mode, text share |
| R8 | Two weeks is too short | High | Medium | Strict day scopes, MVP vs stretch, polish over features |
| R9 | Version drift (MediaPipe, PixiJS, filters) | Medium | Low | ⚠ verify items, pinned versions |
| R10 | Someone else ships a similar idea first | Low | Medium | Ship in two weeks; the theme and the composure hook are the differentiator |

---

## Tuning log

| Date | Config key | Old → New | Why (playtest observation) |
|---|---|---|---|
| | | | |

## Measured values

| Quantity | Value | Date |
|---|---|---|
| Tracking Hz (dev laptop) | | |
| Render fps (VHS, 20 Wicks) | | |
| `dist/` size | | |
| itch.io camera behaviour | | |
| Clip format produced on your Chrome | | |

---

## Progress log

Add an entry at the end of every session. Newest at the bottom.

```
### YYYY-MM-DD — Day N — <in progress | done | blocked>
- Done:
- Tests: <command> → <result>
- Measured:
- Version pins:
- Spec changes (approved on <date>):
- Tuning changes (also in the tuning log):
- Next session starts with:
```
